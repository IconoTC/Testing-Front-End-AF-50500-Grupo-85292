const { Builder, By, until } = require("selenium-webdriver");
const assert = require('assert');

(async function formulario(){

    let webdriver;

    try{
        // Crear instancia de webdriver sobre navegador Chrome
        webdriver = await new Builder().forBrowser('chrome').build();

        // Abrir la pagina de Google
        await webdriver.get('https://www.selenium.dev/selenium/web/web-form.html');

        // Detener la ejecucion para que le de tiempo a meter los datos de busqueda
        await new Promise(resolve => setTimeout(resolve, 4000));

        // Validar el titulo de la pagina
        let titulo = await webdriver.getTitle();
        assert.strictEqual(titulo, 'Web form');

        // Buscar campo de texto e introducir la palabra Selenium
        const campoTexto = await webdriver.findElement(By.name("my-text"));
        await campoTexto.sendKeys("Selenium");

        // Encontrar el boton y hacer click
        let boton = await webdriver.findElement(By.css("button"));
        await boton.click();

        // Esperar y recibir el mensaje
        let mensaje = await webdriver.wait(until.elementLocated(By.id('message')), 5000);
        let textoMensaje = await mensaje.getText();

        // Validar que el mensaje es Received!
        assert.strictEqual(textoMensaje, "Received!");

        console.log("Prueba realizada con exito");
    } catch (error){
        console.error("Ha habido un error en la prueba " + error);
    } finally {
        // Cerrar el navegador
        await webdriver.quit();
    }
 
})();