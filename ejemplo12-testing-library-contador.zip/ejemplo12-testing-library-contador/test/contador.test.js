const { screen, fireEvent} = require('@testing-library/dom');
require('@testing-library/jest-dom');

beforeEach( () => {
    // Recrear la pagina HTML donde haremos las pruebas
    document.body.innerHTML = `
    <div>
        <button id="incrementar">Incrementar</button>
        <span id="valor">0</span>
    </div>
    `;

    // Simulamos que cargamos el script del contador
    let boton = document.getElementById('incrementar');
    let span = document.getElementById('valor');

    boton.addEventListener('click', () => {
        let valor = parseInt(span.textContent);
        span.textContent = valor + 1;
    });
});

test('el valor inicial del contador es 0', () => {
    // Comprobar que en la pantalla vemos el texto 0
    expect(screen.getByText('0')).toBeInTheDocument();
});

test('al hacer click en el boton, se incrementa el valor', () => {
    let boton = screen.getByText("Incrementar");
    fireEvent.click(boton);
    expect(screen.getByText('1')).toBeInTheDocument();
    fireEvent.click(boton);
    expect(screen.getByText('2')).toBeInTheDocument();
    fireEvent.click(boton);
    expect(screen.getByText('3')).toBeInTheDocument();
});