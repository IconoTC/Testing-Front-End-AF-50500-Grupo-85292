let boton = document.getElementById('incrementar');
let span = document.getElementById('valor');

boton.addEventListener('click', () => {
    let valor = parseInt(span.textContent);
    span.textContent = valor + 1;
});