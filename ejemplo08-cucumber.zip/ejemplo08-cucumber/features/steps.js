const { Given, When, Then } = require('@cucumber/cucumber');
const assert = require('assert');

let numeros = [];
let resultado;

Given('tengo los numeros {int} y {int}', (num1, num2) => {
    numeros = [num1, num2];
});

When('los sumo', () => {
    resultado = numeros[0] + numeros[1];
});

Then('el resultado debe ser {int}', (esperado) => {
    assert.strictEqual(resultado, esperado);
});