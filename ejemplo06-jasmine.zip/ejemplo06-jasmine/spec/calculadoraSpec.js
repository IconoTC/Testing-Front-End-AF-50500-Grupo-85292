const calculadora = require('../src/calculadora');

describe('Pruebas de calculadora', () => {

    beforeAll( () => {
        console.log("Se ejecuta una vez al principio");
    } );

    afterAll( () => {
        console.log("Se ejecuta una vez al final");
    });

    beforeEach(() => {
        console.log("Se ejecuta al inicio de cada prueba");
    });

    afterEach(() => {
        console.log("Se ejecuta al final de cada prueba");
    });

    it('Prueba suma', async () => {
        //console.log("---- suma");
        await expect(calculadora.suma(5,2)).toBe(7);
    }); 

    it('Prueba resta', () => {
        expect(calculadora.resta(5,2)).toBe(3);
    });
    
    it('Prueba multiplicacion', () => {
        expect(calculadora.multiplicacion(5,2)).toBe(10);
    });
    
    it('Prueba division', () => {
        expect(calculadora.division(8,2)).toBe(4);
    }); 

    it('Prueba division por 0', () => {
        //expect(calculadora.division(8,2)).toBe(4);
        expect( () => {calculadora.division(8,0)} ).toThrow();
    }); 
});