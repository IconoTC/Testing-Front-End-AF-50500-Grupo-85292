const express = require('express');
const app = express();

app.use(express.json());

app.get('/api/buscarProducto', (request, response) => {
    response.status(200).json({id: 3, descripcion: 'Teclado', precio: 29.95});
});

app.post('/api/crearProducto', (request, response) => {
    const {id, descripcion, precio} = request.body;
    response.status(200).json({mensaje: 'Producto creado. id:' + id + ", descripcion:" + descripcion + ", precio:" + precio});
});

module.exports = app;