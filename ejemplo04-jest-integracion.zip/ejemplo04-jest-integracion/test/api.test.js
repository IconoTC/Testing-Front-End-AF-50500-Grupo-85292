const request = require('supertest');
const api = require('../src/api');

describe("Pruebas de integracion con Jest y Supertest", () => {

    test("GET buscar un producto", async() => {
        const respuesta = await request(api).get('/api/buscarProducto');
        expect(respuesta.statusCode).toBe(200);
        expect(respuesta.body.id).toBe(3);
    });

    test("POST crear un producto", async() => {
        const respuesta = await request(api)
            .post('/api/crearProducto')
            .send({id:4, descripcion:'Raton', precio:15});
        expect(respuesta.statusCode).toBe(200);
        console.log(respuesta.body.mensaje);
        expect(respuesta.body.mensaje).toBe('Producto creado. id:4, descripcion:Raton, precio:15');
    });

});