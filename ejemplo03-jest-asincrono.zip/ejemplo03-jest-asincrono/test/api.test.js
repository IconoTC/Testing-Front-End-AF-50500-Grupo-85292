let buscarProducto = require('../src/api');

test('buscando producto', async () => {
    let producto = await buscarProducto();

    expect(producto.precio < 0).toBeFalsy();
    expect(producto.descripcion.length > 3).toBeTruthy();
});



