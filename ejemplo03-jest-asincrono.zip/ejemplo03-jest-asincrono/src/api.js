async function buscarProducto(){
    // Simulamos una peticion a un servicio rest
    return new Promise( (resolve) => {
        //setTimeout(funcion , ms);
        setTimeout( () => {
            resolve({id: 3, descripcion: 'Teclado', precio: 29.95});
        }, 2000);

    } );
}

module.exports = buscarProducto;