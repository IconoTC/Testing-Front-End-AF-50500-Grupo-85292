let suma = require('../src/sum');

describe("Pruebas del archivo sum.js", () => {

    beforeAll( () => {
        // Abrir el fichero o log donde guardar los resultados
        console.log("Empezando a probar sum.js")
    });

    afterAll( () => {
        // Cerrar o liberar los recursos
        console.log("Terminado de probar sum.js")
    });

    beforeEach(() => {
        console.log("Ejecutando el test");
    });

    afterEach(() => {
        console.log("Finalizado el test");
    });

    //test(titulo, prueba)
    test("Probando funcion suma", () => {
        expect(suma(5,3)).toBe(8);
    });

    test("Probar la igualdad", () => {
        expect({a:5, b:3}).toEqual({a:5, b:3});
    });

    test("Probar true", () => {
        expect(suma(5,3) > 0).toBeTruthy();
    });

    test("Probar false", () => {
        expect(suma(5,3) < 0).toBeFalsy();
    });
});

