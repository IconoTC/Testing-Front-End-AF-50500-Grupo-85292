const { mandarEmail } = require("../js/email");
const { screen, fireEvent } = require('@testing-library/dom');
const { axe, toHaveNoViolations } = require('jest-axe');
require('@testing-library/jest-dom');
expect.extend(toHaveNoViolations);

beforeEach( () => {
    document.body.innerHTML = `
        <form aria-label="Formulario de Email">
            <label for="email">Email</label>
            <input type="email" id="email" />
            <button type="button" id="enviar">Enviar</button>
            <span id="mensaje"></span>
        </form>
    `;
    mandarEmail();
} );

test('testear el mensaje de error si no hay email', () => {
    fireEvent.click(screen.getByText("Enviar"));
    expect(screen.getByRole('alert')).toHaveTextContent("El email es obligatorio");
});

test('testear el mensaje si el mail es correcto', () => {
    screen.getByLabelText('Email').value = "pepito@gmail.com";
    fireEvent.click(screen.getByText("Enviar"));
    expect(screen.getByRole('status')).toHaveTextContent("Email correcto");
});

test('testear si cumple con las reglas basicas de accesibilidad', async() => {
    const resultados = await axe(document.body);
    expect(resultados).toHaveNoViolations();
});
