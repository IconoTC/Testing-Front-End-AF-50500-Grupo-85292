function mandarEmail(){
    document.getElementById("enviar").addEventListener('click', () => {
        let emailTxt = document.getElementById("email");
        let span = document.getElementById("mensaje");

        if (!emailTxt.value){
            span.textContent = "El email es obligatorio";
            span.setAttribute('role', 'alert');
        } else {
            span.textContent = "Email correcto";
            span.setAttribute('role', 'status');
        }
    });
}

module.exports = {mandarEmail};