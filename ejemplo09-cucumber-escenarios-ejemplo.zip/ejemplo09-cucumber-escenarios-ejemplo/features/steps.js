const { Given, When, Then } = require('@cucumber/cucumber');
const assert = require('assert');
const Calculadora = require('../src/calculadora');

let calculadora;

Given('La calculadora esta lista', () => {
    calculadora = new Calculadora();
});

When('el usuario ingresa {int} y {int}', (num1, num2) => {
    calculadora.ingresarNumeros(num1, num2);
});

Then('realiza la operacion {string}', (operacion) => {
    calculadora.operar(operacion);
});

Then('el resultado debe ser {int}', (esperado) => {
    assert.strictEqual(calculadora.obtenerResultado(), esperado);
});

Then('debe mostrar un error {string}', (esperado) => {
    assert.strictEqual(calculadora.obtenerError(), esperado);
});