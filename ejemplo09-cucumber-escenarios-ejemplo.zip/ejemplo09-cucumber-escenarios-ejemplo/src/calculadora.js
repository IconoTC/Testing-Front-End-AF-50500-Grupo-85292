class Calculadora{
    constructor(){
        this.numero1 = 0;
        this.numero2 = 0;
        this.resultado = 0;
        this.error = null;
    }

    ingresarNumeros(n1, n2){
        this.numero1 = n1;
        this.numero2 = n2;
    }

    operar(tipo){
        this.error = null;
        switch (tipo) {
            case "suma":
                this.resultado = this.numero1 + this.numero2;
                break;
        
            case "resta":
                this.resultado = this.numero1 - this.numero2;
                break;
        
            case "multiplicacion":
                this.resultado = this.numero1 * this.numero2;
                break;
        
            case "division":
                if (this.numero2 == 0){
                    this.error = "No se puede dividir por cero";
                } else {
                    this.resultado = this.numero1 / this.numero2;
                }              
                break;
                
            default:
                this.error = "Operacion no valida";
        }
    }

    obtenerResultado(){
        return this.resultado;
    }

    obtenerError(){
        return this.error;
    }
}

module.exports = Calculadora;