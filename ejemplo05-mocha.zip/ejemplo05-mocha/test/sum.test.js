const suma = require('../src/sum');
const expect = require('chai').expect;

describe("Pruebas del archivo sum.js", () => {

    it("probando funcion suma", () => {
        expect(suma(5,3)).to.equal(8);
    });
});


