const Calculadora = require('../src/calculadora');

describe("Pruebas de la calculadora", () => {
    let calc;

    beforeAll( () => {
        calc = new Calculadora();
    });

    test("Probando suma", () => {
        expect(calc.suma(5,3)).toBe(8);
    });

    test("Probando resta", () => {
        expect(calc.resta(5,3)).toBe(2);
    });

    test("Probando multiplicacion", () => {
        expect(calc.multiplicacion(5,3)).toBe(15);
    });

    test("Probando division", () => {
        expect(calc.division(6,3)).toBe(2);
    });

    test("Probando excepcion en division", () => {
        // No funciona porque salta la excepcion
        //expect(calc.division(6,0)).toThrow("No se puede dividir por cero");

        //expect(() => calc.division(6,0)).toThrow("No se puede dividir por cero");
        expect(() => calc.division(6,0)).toThrow();

        // Comprobar el tipo de excepcion
        expect(() => calc.division(6,0)).toThrow(Error);
    });
});

