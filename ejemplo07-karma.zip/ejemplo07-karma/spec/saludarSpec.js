describe("Probando funcion saludar", () => {

    it("Probando tipo retorno", () => {
        expect(typeof saludar('Pepito')).toBe('string');
    }); 

    it("Probando mensaje", () => {
        expect(saludar('Pepito')).toBe("Buenas tardes Pepito");
    }); 
});