const { Builder, By, until } = require("selenium-webdriver");

(async function google(){

    // Crear instancia de webdriver sobre navegador Chrome
    let webdriver = await new Builder().forBrowser('chrome').build();

    // Abrir la pagina de Google
    await webdriver.get('https://www.google.com');

    // Detener la ejecucion para que le de tiempo a meter los datos de busqueda
    await new Promise(resolve => setTimeout(resolve, 4000));

    // Localizamos el cuadro de búsqueda de google
    const campo_busqueda = await webdriver.findElement(By.name("q"));

    // Escribir "Selenium WebDriver"
    await campo_busqueda.sendKeys("Selenium WebDriver");

    // Enviar la busqueda
    await campo_busqueda.submit();
     
    // Detener la ejecuccion para que llegue la respuesta
    await new Promise(resolve => setTimeout(resolve, 4000));

    // Espera hasta que el titulo contenga "Selenium WebDriver"
    await webdriver.wait(until.titleContains("Selenium+WebDriver"), 5000);

    // Mostrar el titulo de la pagina:
    console.log("Titulo de la página: " + await webdriver.getTitle());
    
    // Cerrar el navegador
    await webdriver.quit();
})();