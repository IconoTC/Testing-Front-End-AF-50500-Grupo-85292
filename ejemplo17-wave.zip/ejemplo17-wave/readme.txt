Tenemos dos formas de utilizar wave:

1.- Instalando la extension del navegador: 
    https://chromewebstore.google.com/detail/wave-evaluation-tool/jbbplnpkjmmeebjpijfedlgcdilocofh?pli=1 

2.- utilizando desde su pagina web: 
    https://wave.webaim.org/
