const { JSDOM } = require('jsdom');
const axe = require('axe-core');

const html = `
    <html>
        <body>
            <form>
                <input type="text" id="nombre" />
                <button>Enviar</button>
            </form>
        </body>
    </html>
`;

(async () => {
    const dom = new JSDOM(html, {runScripts: "dangerously"});
    const { window } = dom;

    // Insertar axe-core en el DOM simulado
    window.eval(axe.source);

    // Ejecuta axe-core y muestra resultados
    window.axe.run(window.document)
        .then(resultado => {
            console.log("Reglas no cumplidas:", resultado.violations);
        });  
})();

// Ejecutar node test-axe.js