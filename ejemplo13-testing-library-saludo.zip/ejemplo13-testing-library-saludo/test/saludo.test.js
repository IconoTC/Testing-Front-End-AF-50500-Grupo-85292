const { screen, fireEvent} = require('@testing-library/dom');
require('@testing-library/jest-dom');
const { saludar } = require('../js/saludo');

beforeEach( () => {
    document.body.innerHTML = `
    <form>
        <input type="text" id="nombre" />
        <button id="mostrar">Mostrar saludo</button>

        <span id="saludo"></span>
    </form>
    `;
    saludar();
});

test('El saludo es personalizado', () => {
    // Simulamos que el usuario introduce como nombre Anabel
    screen.getByRole('textbox').value = 'Anabel';

    let boton = screen.getByText('Mostrar saludo');
    fireEvent.click(boton);

    // Comprobamos que el mensaje es "Bienvenid@ Anabel"
    expect(screen.getByText("Bienvenid@ Anabel")).toBeInTheDocument();
});