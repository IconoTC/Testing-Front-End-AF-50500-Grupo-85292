function saludar(){
    let boton = document.getElementById("mostrar");

    boton.addEventListener('click', () => {
        let nombre = document.getElementById("nombre").value;
        let mensaje = "Bienvenid@ " + nombre;
        document.getElementById("saludo").textContent = mensaje;
    });
}

module.exports = { saludar };