const { screen, fireEvent } = require('@testing-library/dom');
const { axe, toHaveNoViolations } = require('jest-axe');
const { saludar } = require('../js/formulario');

expect.extend(toHaveNoViolations);
require('@testing-library/jest-dom');

beforeEach( () => {
    document.body.innerHTML = `
    <form aria-label="Formulario de saludo">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" />
        <button type="button" id="mostrar">Mostrar saludo</button>

        <span id="saludo"></span>
    </form>
    `;
    saludar();
});

test('muestra el mensaje personalizado', () => {
    screen.getByRole('textbox').value = "Pepito";
    fireEvent.click(screen.getByText('Mostrar saludo'));
    expect(screen.getByText('Bienvenid@ Pepito')).toBeInTheDocument();
});

test('cumple con las reglas de accesibilidad', async() => {
    const resultados = await axe(document.body);
    expect(resultados).toHaveNoViolations();
});