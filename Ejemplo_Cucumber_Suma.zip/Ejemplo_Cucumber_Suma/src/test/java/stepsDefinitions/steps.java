package stepsDefinitions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class steps {
	
	private int numero1;
	private int numero2;
	private int resultado;
	
	@Given("tengo los numeros {int} y {int}")
	public void tengo_los_numeros_y(Integer n1, Integer n2) {
		numero1 = n1;
		numero2 = n2;
	}
	
	@When("los sumo")
	public void los_sumo() {
		resultado = numero1 + numero2;
	}
	
	@Then("el resultado debe ser {int}")
	public void el_resultado_debe_ser(Integer esperado) {
		assertEquals(esperado.intValue(), resultado);
	}

}
